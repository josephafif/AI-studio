# Lennart

Svensk AI-assistent inriktad på cybersäkerhet och IT-säkerhet. Besvarar frågor och för enklare samtal.

| Egenskap | Värde |
|---|---|
| Användningsområde | Cybersäkerhet och IT-säkerhet |
| Språk | Svenska |
| Arkitektur | Transformer (GPT, decoder-only) |
| Parametrar | 995,544 |
| Lager | 4 |
| Attention heads | 4 |
| Modellbredd (d_model) | 132 |
| Context length | 128 tokens |
| Ordförråd | 1024 (byte-nivå BPE) |
| Skapad | 2026-11-13T10:11:40 |

## Filer

- `config.json` – modellens konfiguration och metadata
- `model.py` – genererad modellkod (PyTorch)
- `tokenizer.json` – tokenizer, skapas vid första träningen
- `checkpoints/` – sparade vikter från träning
- `traningshistorik.json` – logg över genomförda träningskörningar

Modellen är skapad och hanteras av AI Control Center.
