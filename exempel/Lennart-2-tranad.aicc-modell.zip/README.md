# Lennart 2

Svensk AI-assistent inriktad på cybersäkerhet och IT-säkerhet.

| Egenskap | Värde |
|---|---|
| Användningsområde | Cybersäkerhet och IT-säkerhet |
| Språk | Svenska |
| Arkitektur | Transformer (GPT, decoder-only) |
| Parametrar | 8,130,624 |
| Lager | 6 |
| Attention heads | 6 |
| Modellbredd (d_model) | 282 |
| Context length | 256 tokens |
| Ordförråd | 8192 (byte-nivå BPE) |
| Skapad | 2026-11-13T15:13:53 |

## Filer

- `config.json` – modellens konfiguration och metadata
- `model.py` – genererad modellkod (PyTorch)
- `tokenizer.json` – tokenizer, skapas vid första träningen
- `checkpoints/` – sparade vikter från träning
- `traningshistorik.json` – logg över genomförda träningskörningar

Modellen är skapad och hanteras av AI Control Center.
